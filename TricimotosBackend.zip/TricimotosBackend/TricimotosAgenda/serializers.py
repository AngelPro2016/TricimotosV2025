from rest_framework import serializers
from .models import Solicitud, Aceptacion

class SolicitudSerializer(serializers.ModelSerializer):
    class Meta:
        model = Solicitud
        fields = ['id', 'cliente', 'origen', 'destino', 'hora_programada', 'estado', 'tricimotero']
        read_only_fields = ['cliente', 'estado', 'tricimotero']


class AceptacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Aceptacion
        fields = '__all__'
        read_only_fields = ['tricimotorero', 'aceptada_en']
