from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404

from .models import Solicitud, Aceptacion, Ubicacion
from .serializers import SolicitudSerializer

class SolicitudListCreateView(generics.ListCreateAPIView):
    queryset = Solicitud.objects.all()
    serializer_class = SolicitudSerializer
    ##permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(cliente=self.request.user)

class SolicitudesPendientesView(generics.ListAPIView):
    serializer_class = SolicitudSerializer
    ##permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Solicitud.objects.filter(estado='pendiente')

class AceptarSolicitudView(APIView):
    #permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        solicitud = get_object_or_404(Solicitud, pk=pk)

        if solicitud.estado != 'pendiente':
            return Response({'error': 'Esta solicitud ya fue aceptada.'}, status=status.HTTP_400_BAD_REQUEST)

        Aceptacion.objects.create(
            solicitud=solicitud,
            tricimotorero=request.user
        )
        solicitud.estado = 'aceptada'
        solicitud.save()
        return Response({'mensaje': 'Carrera aceptada con éxito.'}, status=status.HTTP_200_OK)

class CarreraAsignadaView(APIView):
    #permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            solicitud = Solicitud.objects.get(cliente=request.user, estado='aceptada')
            data = {
                "tricimotero": solicitud.tricimotero.username,
                "ubicacion_aproximada": "Coordenadas que se mandan desde el móvil del tricimotero",  # se completará en el frontend
            }
            return Response(data, status=200)
        except Solicitud.DoesNotExist:
            return Response({"mensaje": "No tienes carreras asignadas aún."}, status=404)

class ActualizarUbicacionView(APIView):
    #permission_classes = [IsAuthenticated]

    def post(self, request):
        lat = request.data.get("lat")
        lon = request.data.get("lon")
        Ubicacion.objects.update_or_create(usuario=request.user, defaults={"latitud": lat, "longitud": lon})
        return Response({"mensaje": "Ubicación actualizada."})

class VerUbicacionTricimoteroView(APIView):
    #permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            solicitud = Solicitud.objects.get(cliente=request.user, estado='aceptada')
            ubicacion = Ubicacion.objects.get(usuario=solicitud.tricimotero)
            return Response({"lat": ubicacion.latitud, "lon": ubicacion.longitud})
        except:
            return Response({"error": "No se encontró ubicación"}, status=404)
        
class VerCarreraAsignadaView(APIView):
    #permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            solicitud = Solicitud.objects.get(cliente=request.user, estado='aceptada')
            ubicacion = Ubicacion.objects.get(usuario=solicitud.tricimotero)
            return Response({
                'tricimotero': solicitud.tricimotero.username,
                'latitud': ubicacion.latitud,
                'longitud': ubicacion.longitud
            })
        except Solicitud.DoesNotExist:
            return Response({'mensaje': 'Aún no se ha aceptado tu carrera.'}, status=404)
        except Ubicacion.DoesNotExist:
            return Response({'mensaje': 'Ubicación no disponible.'}, status=404)

class ActualizarUbicacionView(APIView):
    #permission_classes = [IsAuthenticated]

    def post(self, request):
        lat = request.data.get("latitud")
        lon = request.data.get("longitud")
        if not lat or not lon:
            return Response({"error": "Faltan coordenadas"}, status=400)

        Ubicacion.objects.update_or_create(
            usuario=request.user,
            defaults={"latitud": lat, "longitud": lon}
        )
        return Response({"mensaje": "Ubicación actualizada."})