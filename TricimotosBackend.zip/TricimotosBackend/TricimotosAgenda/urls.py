from django.urls import path
from . import views

urlpatterns = [
    path('api/solicitudes/', views.SolicitudListCreateView.as_view(), name='solicitud-list-create'),
    path('api/solicitudes/pendientes/', views.SolicitudesPendientesView.as_view(), name='solicitudes-pendientes'),
    path('api/solicitudes/<int:pk>/aceptar/', views.AceptarSolicitudView.as_view(), name='aceptar-solicitud'),
    path('api/carrera/asignada/', views.VerCarreraAsignadaView.as_view(), name='carrera-asignada'),
    path('api/ubicacion/actualizar/', views.ActualizarUbicacionView.as_view(), name='actualizar-ubicacion'),
]
